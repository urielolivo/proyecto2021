from django.apps import AppConfig


class RegistroConfig(AppConfig):
    name = 'registro'
