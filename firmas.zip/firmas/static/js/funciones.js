$(document).ready(function(){
        $("#firmar").click(function(){
                $("#firmar_input").val('firmar');
		return true;
        });
	$("#verificar").click(function(){
                $("#verificar_input").val('verificar');
                return true;
        });
});
